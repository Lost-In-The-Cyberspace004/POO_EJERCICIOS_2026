
import java.util.Scanner;

class Vehiculo {

    String Color;
    String Placa;

    Vehiculo(String Color, String Placa) {
        this.Color = Color;
        this.Placa = Placa;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }

}

class Auto extends Vehiculo {

    int Pasajeros;

    Auto(String Color, String Placa, int pasajeros) {
        super(Color, Placa);
        this.Pasajeros = pasajeros;
    }
}

class Moto extends Vehiculo {

    boolean Casco;

    Moto(String Color, String Placa, boolean casco) {
        super(Color, Placa);
        this.Casco = casco;
    }
}

class Procesos {

    int filas;
    int columnas;

    //declaramos la matriz de objetos
    Vehiculo Vehiculo_Ad[][];

    Procesos(int Filas, int Columnas) {
        this.filas = Filas;
        this.columnas = Columnas;

        //Inicializamos la matriz de objetos dentro del constructor o nos saltará error
        this.Vehiculo_Ad = new Vehiculo[Filas][Columnas];

    }

    //Recibimos un dato de tipo objetos como parametro "(Vehiculo V)"
    public boolean Ingresar_Vehiculo(Vehiculo V, String placa, String Color) {
        for (int i = 0; i < Vehiculo_Ad.length; i++) {
            for (int j = 0; j < Vehiculo_Ad[i].length; j++) {
                if (Vehiculo_Ad[i][j] == null) {
                    Vehiculo_Ad[i][j] = V;
                    System.out.println("Vehiculo guardado en la posicion: " + "[" + i + "] [" + j + "] Con placa: " + placa + " Color: " + Color);
                    return true;
                }
            }
        }
        System.out.println("No se pudo guardar");
        return false;
    }

    public void buscar_Vehiculo(String Placa) {
        String Placa_Encontrada = Placa;
        boolean encontrado = false;
        for (int i = 0; i < Vehiculo_Ad.length; i++) {
            for (int j = 0; j < Vehiculo_Ad[i].length; j++) {
                if (Vehiculo_Ad[i][j] != null) {
                    if (Vehiculo_Ad[i][j].getPlaca().equalsIgnoreCase(Placa)) {
                        System.out.println("Placa encontrada: " + Placa_Encontrada);
                        encontrado = true;
                    }
                }
            }
        }
        if (!encontrado) {
            System.out.println("La placa " + Placa + " No ha sido encontrada o registrada");
        }
    }

    public boolean Retirar_Vehiculo(String Placa) {
        for (int i = 0; i < Vehiculo_Ad.length; i++) {
            for (int j = 0; j < Vehiculo_Ad[i].length; j++) {
                if (Vehiculo_Ad[i][j] != null) {
                    if (Vehiculo_Ad[i][j].getPlaca().equalsIgnoreCase(Placa)) {

                        //eliminamos el vehiculo usando null en esa posicion encontrada
                        Vehiculo_Ad[i][j] = null;

                        System.out.println("Vehiculo eliminado");
                        return true;
                    }
                }
            }
        }
        System.out.println("El vehiculo no existe");
        return false;
    }

    public int Numero_De_Vehiculos(String tipo) {
        int contador = 0; //Variable contadora

        for (int i = 0; i < Vehiculo_Ad.length; i++) {
            for (int j = 0; j < Vehiculo_Ad[i].length; j++) {

                if (Vehiculo_Ad[i][j] != null) {
                    // Si pedimos contar autos
                    if (tipo.equalsIgnoreCase("Auto") && Vehiculo_Ad[i][j] instanceof Auto) {
                        
                        
                        /*
                            Desglose del instalseof
                        
                            Se usa para saber si un Objeto fue creado en base a una clase. 
                            En este caso usamos instanseOf para verificar si el elemento en la matriz de objetos pertenece a la clase auto.
                        */
                        
                        contador++;
                    }
                    // Si pedimos contar motos
                    if (tipo.equalsIgnoreCase("Moto") && Vehiculo_Ad[i][j] instanceof Moto) {
                        contador++;
                    }
                }
            }
        }
        return contador; // Retorna el entero, que seria el contador de vehiculos
    }
}

public class Herencia_Ejercicio_Parqueadero {

    public static void main(String args[]) {
        Scanner EntrUs = new Scanner(System.in);
        Procesos Obj_P = new Procesos(3, 10);

        int Numero_De_Autos = 0;
        int Numero_De_Motos = 0;

        boolean bucle = true;

        while (bucle == true) {
            System.out.println("\n");
            System.out.print("Ingresa la placa: ");
            String Placa = EntrUs.nextLine();

            System.out.print("Ingresa el color: ");
            String Color = EntrUs.nextLine();

            System.out.print("Que deseas añadir: ");
            String Seleccion_1 = EntrUs.nextLine();

            if (Seleccion_1.equalsIgnoreCase("Moto")) {
                System.out.print("Llevas casco?: ");
                boolean casco = EntrUs.nextBoolean();
                EntrUs.nextLine();

                //creamos el objeto de la clase moto
                Moto Obj_Moto = new Moto(Color, Placa, true);

                //Llamamos al obj de la clase Procesos y enviamos el objeto de la clase moto y los datos anteriores
                Obj_P.Ingresar_Vehiculo(Obj_Moto, Placa, Color);


            } else if (Seleccion_1.equalsIgnoreCase("Auto")) {
                System.out.print("Numero de pasajeros: ");
                int N_Pasajeros = EntrUs.nextInt();
                EntrUs.nextLine();

                Auto Obj_Auto = new Auto(Color, Placa, N_Pasajeros);

                Obj_P.Ingresar_Vehiculo(Obj_Auto, Placa, Color);

            }

            System.out.println("\n");
            System.out.println("1-) Buscar vehiculo por placa");
            System.out.println("2-) Retirar Vehiculo");
            System.out.println("3-) Numero de Vehiculos");
            System.out.print("Opcion: ");
            String Opcion = EntrUs.nextLine();

            switch (Opcion) {
                case "1":
                    System.out.print("Placa del vehiculo: ");
                    String Placa_V = EntrUs.nextLine();
                    Obj_P.buscar_Vehiculo(Placa_V);
                    break;
                case "2":
                    System.out.println("Para retirar un vehiculo ingrese su placa: ");
                    String Placa_Vehiculo_A_Retirar = EntrUs.nextLine();
                    Obj_P.Retirar_Vehiculo(Placa_Vehiculo_A_Retirar);
                    break;
                case "3":
                    
                    //creamos variables locales donde cada una enviara un parametro diferente al metodo
                    int autosActuales = Obj_P.Numero_De_Vehiculos("Auto");
                    int motosActuales = Obj_P.Numero_De_Vehiculos("Moto");

                    System.out.println("--- ESTADO DEL PARQUEADERO ---");
                    System.out.println("Autos estacionados: " + autosActuales);
                    System.out.println("Motos estacionadas: " + motosActuales);
                    System.out.println("Total: " + (autosActuales + motosActuales));
                    break;
                default:
                    System.out.println("Error");
                    break;
            }

        }

    }
}
