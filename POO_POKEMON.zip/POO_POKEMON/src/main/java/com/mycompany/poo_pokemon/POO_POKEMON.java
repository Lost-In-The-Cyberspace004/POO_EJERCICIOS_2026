package com.mycompany.poo_pokemon;

import java.util.Scanner;

class Pokemon_Procesos {

    Scanner EntrUs = new Scanner(System.in);

    String Pokemon;
    int vidas;
    int defensa;
    int contrataque;
    float puntos;

    Pokemon_Procesos(String Pokemon, int vidas, int defensa, int contrataque, float puntos) {
        this.Pokemon = Pokemon;
        this.vidas = vidas;
        this.defensa = defensa;
        this.contrataque = contrataque;
        this.puntos = puntos;
    }

    public void MisPokemones(Pokemon_Procesos[] ListaPokemonesPer) {
        System.out.println("\n");
        System.out.println("Propios");
        for (int i = 0; i < ListaPokemonesPer.length; i++) {
            System.out.println("Pokemones: " + ListaPokemonesPer[i].Pokemon + " | " + ListaPokemonesPer[i].vidas + " | " + ListaPokemonesPer[i].puntos + " | " + ListaPokemonesPer[i].defensa + " | " + ListaPokemonesPer[i].contrataque);
        }
    }

    public void PokemonesEnemigos(Pokemon_Procesos[] ListaPokemonesEne) {
        System.out.println("\n");
        System.out.println("Enemigos");
        for (int i = 0; i < ListaPokemonesEne.length; i++) {
            System.out.println("Pokemones: " + ListaPokemonesEne[i].Pokemon + " | " + ListaPokemonesEne[i].vidas + " | " + ListaPokemonesEne[i].puntos + " | " + ListaPokemonesEne[i].defensa + " | " + ListaPokemonesEne[i].contrataque);
        }
        System.out.println("\n");
    }

    public void Pelear(String Pokemon_Personal, String Pokemon_Enemigo, Pokemon_Procesos[] ListaPokemonesPer, Pokemon_Procesos[] ListaPokemonesEne) {
        String PokemonPer = "";
        String PokemonEne = "";
        int VidaEnemigo;
        int PokemonVidaPer;
        boolean EncontradoPokemonPer = false;
        boolean EncontradoPokemonEne = false;
        for (int i = 0; i < ListaPokemonesPer.length; i++) {
            if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(Pokemon_Personal)) {
                PokemonPer = ListaPokemonesPer[i].getPokemon();
                EncontradoPokemonPer = true;
                break;
            }
        }
        if (!EncontradoPokemonPer) {
            System.out.println("Error");
            return; //Para que el metodo se detenga
        }
        for (int i = 0; i < ListaPokemonesEne.length; i++) {
            if (ListaPokemonesEne[i].getPokemon().equalsIgnoreCase(Pokemon_Enemigo)) {
                PokemonEne = ListaPokemonesEne[i].getPokemon();
                EncontradoPokemonEne = true;
                break;
            }
        }
        if (!EncontradoPokemonEne) {
            System.out.println("Error");
            return;
        }
        String Opcion = "";
        boolean Controlador = true;
        do {
            int Ataque = (int) (Math.random() * 3);
            System.out.println("\nPoder 1: Rayos laser");
            System.out.println("Poder 2: Disparos de plasma");
            System.out.println("Poder 3: Escudo de energia");
            System.out.println("Rendirse");
            System.out.println("Salir");
            System.out.print("Opcion: ");
            Opcion = EntrUs.nextLine();

            if (Opcion.equalsIgnoreCase("salir")) {
                Controlador = false;
                break;
            }
            if (Opcion.equalsIgnoreCase("Rendirse")) {
                System.out.println("\n" + PokemonPer + " Se rinde. Victoria para " + PokemonEne);
                Controlador = false;
                break;
            }

            if (Opcion.equalsIgnoreCase("1")) {
                System.out.println("\n" + PokemonPer + " Usa Rayos laser alv");
                System.out.println("A " + PokemonEne + " Se le bajan 2 palitos");
                for (int i = 0; i < ListaPokemonesEne.length; i++) {
                    if (ListaPokemonesEne[i].getPokemon().equalsIgnoreCase(PokemonEne)) {
                        VidaEnemigo = ListaPokemonesEne[i].getVidas() - 10; //Bajar la vida del enemigo
                        ListaPokemonesEne[i].setVidas(VidaEnemigo);
                        System.out.println(PokemonEne + " vida del enemigo: " + VidaEnemigo);
                    }
                }
                if (Ataque == 1) {
                    System.out.println(PokemonEne + " Usa ataque galactico");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 10;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                } else if (Ataque == 2) {
                    System.out.println(PokemonEne + " Usa invicacion del poder de Dios");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 20;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                } else if (Ataque == 3) {
                    System.out.println(PokemonEne + " Usa Escudo planetario");
                } else if (Ataque == 0) {
                    System.out.println(PokemonEne + " Usa ataque de sida");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 30;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                }
            }

            if (Opcion.equalsIgnoreCase("2")) {
                System.out.println("\n" + PokemonPer + " Usa disparos de plasma ionizado");
                System.out.println("A " + PokemonEne + " Se le bajan 10 palitos");
                for (int i = 0; i < ListaPokemonesEne.length; i++) {
                    if (ListaPokemonesEne[i].getPokemon().equalsIgnoreCase(PokemonEne)) {
                        VidaEnemigo = ListaPokemonesEne[i].getVidas() - 20;
                        ListaPokemonesEne[i].setVidas(VidaEnemigo);
                        System.out.println(PokemonEne + " vida del enemigo: " + VidaEnemigo);
                    }
                }
                if (Ataque == 1) {
                    System.out.println(PokemonEne + " Usa ataque galactico");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 10;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                } else if (Ataque == 2) {
                    System.out.println(PokemonEne + " Usa invicacion del poder de Dios");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 20;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                } else if (Ataque == 3) {
                    System.out.println(PokemonEne + " Usa Escudo planetario");
                } else if (Ataque == 0) {
                    System.out.println(PokemonEne + " Usa ataque de sida");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 30;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                }
            }

            if (Opcion.equalsIgnoreCase("3")) {
                System.out.println("\n" + PokemonPer + " Usa escudos de energia");
                System.out.println("A " + PokemonEne + " Se le bajan 0 palitos");
                if (Ataque == 1) {
                    System.out.println(PokemonEne + " Usa ataque galactico");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 10;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + PokemonVidaPer);
                        }
                    }
                } else if (Ataque == 2) {
                    System.out.println(PokemonEne + " Usa invocacion del poder de Dios");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 20;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + ListaPokemonesPer[i].getVidas());
                        }
                    }
                } else if (Ataque == 3) {
                    System.out.println(PokemonEne + " Usa Escudo planetario");
                } else if (Ataque == 0) {
                    System.out.println(PokemonEne + " Usa ataque de sida");
                    for (int i = 0; i < ListaPokemonesPer.length; i++) {
                        if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(PokemonPer)) {
                            PokemonVidaPer = ListaPokemonesPer[i].getVidas() - 30;
                            ListaPokemonesPer[i].setVidas(PokemonVidaPer);
                            System.out.println("Vida de tu pokemon: " + ListaPokemonesPer[i].getVidas());
                        }
                    }
                }
            }

            System.out.println("\n");

            for (int i = 0; i < ListaPokemonesPer.length; i++) {
                if (ListaPokemonesPer[i].getPokemon().equalsIgnoreCase(Pokemon_Personal)) {
                    if (ListaPokemonesPer[i].getVidas() < 0) {
                        System.out.println(Pokemon_Personal + " ha muerto");
                        Controlador = false;
                        break;
                    } else {
                        ListaPokemonesPer[i].setPuntos(100);
                        System.out.println(Pokemon_Personal + " Aun esta de pie");
                    }
                }
            }

            System.out.println("\n");

            for (int i = 0; i < ListaPokemonesEne.length; i++) {
                if (ListaPokemonesEne[i].getPokemon().equalsIgnoreCase(Pokemon_Enemigo)) {
                    if (ListaPokemonesEne[i].getVidas() < 0) {
                        System.out.println(Pokemon_Enemigo + "Muerto");
                        Controlador = false;
                        break;
                    } else {
                        ListaPokemonesEne[i].setPuntos(100);
                        System.out.println(Pokemon_Enemigo + " Aun esta de pie");
                    }
                }
            }

            System.out.println("\n");

        } while (Controlador);
    }

    public void estadisticas(Pokemon_Procesos[] ListaPokemonesPer, Pokemon_Procesos[] ListaPokemonesEne) {
        for (int i = 0; i < ListaPokemonesPer.length; i++) {
            System.out.println("\n Pokemon: " + ListaPokemonesPer[i].getPokemon() + " Puntos " + ListaPokemonesPer[i].getPuntos());
        }
        for (int i = 0; i < ListaPokemonesEne.length; i++) {

            System.out.println("\n Pokemon: " + ListaPokemonesEne[i].getPokemon() + " Puntos " + ListaPokemonesEne[i].getPuntos() + "\n");
        }
    }

    public int getVidas() {
        return vidas;
    }

    public void setVidas(int vidas) {
        this.vidas = vidas;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public int getContrataque() {
        return contrataque;
    }

    public void setContrataque(int contrataque) {
        this.contrataque = contrataque;
    }

    public float getPuntos() {
        return puntos;
    }

    public void setPuntos(float puntos) {
        this.puntos = puntos;
    }

    public String getPokemon() {
        return Pokemon;
    }

    public void setPokemon(String Pokemon) {
        this.Pokemon = Pokemon;
    }

}

public class POO_POKEMON {

    public static void main(String[] args) {
        Scanner EntrUs = new Scanner(System.in);

        Pokemon_Procesos Obj = new Pokemon_Procesos("i", 0, 0, 0, 0);

        Pokemon_Procesos[] PokemonesPersonales = new Pokemon_Procesos[5];
        PokemonesPersonales[0] = new Pokemon_Procesos("Vaporeon", 100, 60, 60, 0f);
        PokemonesPersonales[1] = new Pokemon_Procesos("Gardevoir", 100, 50, 20, 0f);
        PokemonesPersonales[2] = new Pokemon_Procesos("Lopunny", 100, 50, 50, 0f);
        PokemonesPersonales[3] = new Pokemon_Procesos("Braixen", 100, 100, 100, 0f);
        PokemonesPersonales[4] = new Pokemon_Procesos("Pikachu", 100, 50, 300, 0f);

        Pokemon_Procesos[] PokemonesAdversarios = new Pokemon_Procesos[5];
        PokemonesAdversarios[0] = new Pokemon_Procesos("Mewtwo", 100, 100, 100, 0f);
        PokemonesAdversarios[1] = new Pokemon_Procesos("Gyarados", 100, 100, 100, 0f);
        PokemonesAdversarios[2] = new Pokemon_Procesos("Chulhu", 100, 100, 100, 0f);
        PokemonesAdversarios[3] = new Pokemon_Procesos("Yveltal", 100, 100, 100, 0f);
        PokemonesAdversarios[4] = new Pokemon_Procesos("Banette", 100, 100, 100, 0f);

        String Opcion = "";
        String Pokemon_Personal = "", Pokemon_Adversario = "";
        do {
            System.out.println("1-) Pelear");
            System.out.println("2-) Ver estadisticas x pokemon");
            System.out.println("3-) Pokemones personales y Pokemones enemigos");
            System.out.print("Opcion: ");
            Opcion = EntrUs.nextLine();
            if (Opcion.equalsIgnoreCase("Salir")) {
                break;
            }
            if (Opcion.equalsIgnoreCase("1")) {
                System.out.print("Ingresa tu pokemon: ");
                Pokemon_Personal = EntrUs.nextLine();
                System.out.print("Ingresa tu Pokemon enemigo: ");
                Pokemon_Adversario = EntrUs.nextLine();
                Obj.Pelear(Pokemon_Personal, Pokemon_Adversario, PokemonesPersonales, PokemonesAdversarios);
            }
            if (Opcion.equalsIgnoreCase("2")) {
                Obj.estadisticas(PokemonesPersonales, PokemonesAdversarios);
            }
            if (Opcion.equalsIgnoreCase("3")) {
                Obj.MisPokemones(PokemonesPersonales);
                Obj.PokemonesEnemigos(PokemonesAdversarios);
            }
        } while (true);
    }
}
