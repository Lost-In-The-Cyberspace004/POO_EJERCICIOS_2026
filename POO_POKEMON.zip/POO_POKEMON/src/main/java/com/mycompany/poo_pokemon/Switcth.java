package com.mycompany.poo_pokemon;
import java.util.Scanner;
public class Switcth {
    public static void main(String args[]){
        
        Scanner EntrUs = new Scanner(System.in);
        
        System.out.println("Ingresa un numero: ");
        int Numero = EntrUs.nextInt();
        
        switch(Numero){
            case 1:
                System.out.println("ingresaste el numero 1");
                break;
            case 2:
                System.out.println("Ingresaste el numero 2");
                break;
            default:
                System.out.println("Ingresaste otro numero");
                break;    
        }
        
        System.out.println("\n");
        EntrUs.nextLine();
        
        System.out.println("Ingresa una palabra: ");
        String Palabra = EntrUs.nextLine();
        switch(Palabra){
            case "vaca":
                System.out.println("Escribiste vaca");
                break;
            default:
                System.out.println("Otra palabra");
                break;
        }
        
    }
}
